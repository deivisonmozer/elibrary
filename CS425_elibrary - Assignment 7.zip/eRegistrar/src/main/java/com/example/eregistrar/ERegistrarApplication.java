package com.example.eregistrar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ERegistrarApplication {

    public static void main(String[] args) {
        SpringApplication.run(ERegistrarApplication.class, args);
    }

}
