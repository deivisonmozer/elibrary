package com.example.eregistrar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ERegistrarApplicationTests {

    @Test
    void contextLoads() {
    }

}
